package com.lec.ex;

public class VarEx06 {
	public static void main(String[] args) {
			// 기초데이터 타입
			int i;
			i = 10;
			char gender = '남';
			//창조데이터 타입 (객체데이터 타입)
			String name = "Hong";
			name = "홍";
			i= 100;
	}
}