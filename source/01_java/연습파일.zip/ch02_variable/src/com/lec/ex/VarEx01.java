package com.lec.ex;

public class VarEx01 {
	public static void main(String[] args) {
		// 변수타입 변수명 = 값;
		int age = 27; // 4byte 정수
		// age = 27.5; 변수 타입과 다른 값
		String name = "제니";
		System.out.println("안녕하세요. " + age + "살 "+ name +"씨");// ctrl + alt + ↓ (한줄복사)
		System.out.println("안녕하세요. " + age + "살 "+ name +"씨");// ctrl + alt + ↓ (한줄복사)
		System.out.println("안녕하세요. " + age + "살 "+ name +"씨");// ctrl + alt + ↓ (한줄복사)
		age = 28; name="홍길동";
		System.out.println("안녕하세요. " + age + "살 "+ name +"씨");// ctrl + alt + ↓ (한줄복사)
		System.out.println("안녕하세요. " + age + "살 "+ name +"씨");// ctrl + alt + ↓ (한줄복사)
	}
}
