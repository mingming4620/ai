package com.lec.loop;
// 10, 9, 8, ... 1.
public class Ex07while {
	public static void main(String[] args) {
		int i = 10;
		while (i>0) {
			System.out.print(i + "\t");
			i--;			
		}
//		 for(int i=10 ; i>0 ; i--) { 
//			 System.out.print(i + "\t");
//		 }
	}
}
