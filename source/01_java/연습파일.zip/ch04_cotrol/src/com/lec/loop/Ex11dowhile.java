package com.lec.loop;
//
public class Ex11dowhile {
	public static void main(String[] args) {
		
	}

}
