package com.lec.loopQuiz;

public class Quiz2 {

}
