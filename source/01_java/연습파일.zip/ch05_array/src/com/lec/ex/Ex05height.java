package com.lec.ex;

public class Ex05height {

}
